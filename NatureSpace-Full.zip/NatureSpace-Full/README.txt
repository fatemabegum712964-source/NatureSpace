NATURESPACE — FULL STARTER PROJECT
=================================
This is a separate website. It does not modify your FileFox project.

FILES
-----
index.html       The complete responsive gallery and upload UI
README.txt       This setup guide
firestore.rules  Suggested database security rules
storage.rules    Suggested image storage security rules

PART 1 — PUBLISH A BASIC VERSION
--------------------------------
1. Download and extract NatureSpace-Full.zip on your phone.
2. In GitHub, create a NEW repository called naturespace (not filefox).
3. Open the new repository > Add file > Upload files.
4. Upload index.html, firestore.rules, and storage.rules (README is optional).
5. Commit changes.
6. Open Settings > Pages.
7. Under Build and deployment select Deploy from a branch, branch main, folder /(root), then Save.
8. Wait a few minutes. The URL will be:
   https://YOUR-GITHUB-USERNAME.github.io/naturespace/

At first the site runs in DEMO mode: sample images show, and photos selected from your phone appear only in that browser.

PART 2 — ENABLE SHARED PUBLIC PHOTO UPLOADS WITH FIREBASE
---------------------------------------------------------
You must configure Firebase yourself. The site cannot securely upload to a shared online gallery until this is done.

A. Create a Firebase project
1. Open https://console.firebase.google.com/ and create a project named NatureSpace.
2. Add a Web App (</> icon), register it, and copy the Firebase config object.
3. In Firebase Console > Authentication > Sign-in method, enable Anonymous sign-in.
4. In Firebase Console > Firestore Database, create a database.
5. In Firebase Console > Storage, get started and create the default bucket.
   If Storage asks for a billing plan, check the current Firebase pricing and availability before proceeding; do not enable paid billing unless you and your parent/guardian understand the costs.

B. Add config to index.html
Find this block near the bottom:
  const firebaseConfig = {
    apiKey: "PASTE_YOUR_FIREBASE_API_KEY",
    authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_PROJECT_ID.appspot.com",
    appId: "PASTE_YOUR_FIREBASE_APP_ID"
  };
Replace the placeholder values with the exact values from your Firebase Web App config.
The storageBucket value must be copied exactly from Firebase; newer projects may use a different bucket domain.

C. Set security rules
In Firebase Console > Firestore Database > Rules, paste the contents of firestore.rules and Publish.
In Firebase Console > Storage > Rules, paste the contents of storage.rules and Publish.

D. Publish the updated index.html
Commit the updated file to the new naturespace repository and wait for GitHub Pages to redeploy.

IMPORTANT SECURITY AND MODERATION NOTES
---------------------------------------
- These starter rules permit public reading and authenticated anonymous users to upload limited image files. Anonymous users can still be abused; review uploads and add moderation/rate limits before promoting the site.
- Anyone can see images that are uploaded to this public gallery. Do not upload private photos or personal information.
- Do not place service-account keys or private secrets in HTML. Firebase web config is intended for client apps; database/storage rules are what protect data.
- The demo likes are local to each browser; shared like counts are not implemented yet.
- Photo upload requires a real Firebase project and correct rules. No configuration can be pre-filled because it belongs to your account.
- For a real public community, add report/delete/moderation tools and quotas before advertising the site.
